#!/bin/bash
# controls for the 32k KV-cache KLD (one 32768-token chunk of wikitext), recorded in ~/profiles
d=~/profiles/$(date -u +%Y%m%dT%H%M%SZ)-kvquant-controls; mkdir -p $d; cp $0 $d/ 2>/dev/null
M=$HOME/models/qwen3.8-27b-ost44-v2-wg64-rb4-gptq.gguf
Q6=$HOME/models/Qwen3.8-27B-UD-Q6_K.gguf
B=$HOME/mx-llama.cpp/build-r712/bin
{ echo "label: kvquant-controls"; echo "time: $(date -u +%FT%TZ)"; echo "binary: $B (libggml-hip.so md5 $(md5sum < $B/libggml-hip.so | cut -c1-32))";
  echo "part A: against our model's TP4 f16-cache run (~/tp/kv32k-f16.kld): numerics-only changes and q8_0 without rotation";
  echo "part B: against UD-Q6_K at 32k (~/tp/kv32k-q6k.kld, TP4): our model with f16 / q8_0 / q4_0 caches"; } > $d/meta.txt
ppl() { # GPUS, then llama-perplexity arguments
  local g=$1; shift; local sm=; [ $g != 0 ] && sm="-sm tensor"
  HIP_VISIBLE_DEVICES=$g GGML_CUDA_DISABLE_GRAPHS=1 GGML_NCCL_AR_WIRE=${WIRE:-f16} HSA_FORCE_FINE_GRAIN_PCIE=1 LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib \
    $B/llama-perplexity -f $HOME/ref/wiki.test.raw -c 32768 -b 2048 -ub 2048 --chunks 1 -fa on -ngl 99 -lm dio $sm "$@"
}
row() { printf "%-40s %s\n" "$1" "$(sed -n '/KL divergence statistics/,$p' $2 | grep -E 'Mean PPL\(Q\) |Mean    KLD|Same top p' | tr -s ' ' | tr '\n' ' ')" | tee -a $d/results.txt; }
echo "== A. against our model, TP4, f16 cache" | tee -a $d/results.txt
ppl 0 -m $M --kl-divergence-base ~/tp/kv32k-f16.kld --kl-divergence > $d/a-f16-1gpu.log 2>&1; row "f16 cache, one GPU" $d/a-f16-1gpu.log
WIRE=q8_0 ppl 0,1,2,3 -m $M --kl-divergence-base ~/tp/kv32k-f16.kld --kl-divergence > $d/a-f16-wireq8.log 2>&1; row "f16 cache, TP4, q8_0 all-reduce wire" $d/a-f16-wireq8.log
LLAMA_ATTN_ROT_DISABLE=1 ppl 0,1,2,3 -m $M -ctk q8_0 -ctv q8_0 --kl-divergence-base ~/tp/kv32k-f16.kld --kl-divergence > $d/a-q8-norot.log 2>&1; row "q8_0/q8_0, TP4, rotation off" $d/a-q8-norot.log
echo "== B. against UD-Q6_K, TP4" | tee -a $d/results.txt
ppl 0,1,2,3 -m $Q6 --kl-divergence-base ~/tp/kv32k-q6k.kld > $d/b-base.log 2>&1
grep -E "Final estimate" $d/b-base.log | tee -a $d/results.txt
for kv in f16/f16 q8_0/q8_0 q4_0/q4_0; do
  ppl 0,1,2,3 -m $M -ctk ${kv%/*} -ctv ${kv#*/} --kl-divergence-base ~/tp/kv32k-q6k.kld --kl-divergence > $d/b-${kv/\//-}.log 2>&1
  row "W4A4, $kv cache" $d/b-${kv/\//-}.log
done
ppl 0,1,2,3 -m $Q6 -ctk q8_0 -ctv q8_0 --kl-divergence-base ~/tp/kv32k-q6k.kld --kl-divergence > $d/b-q6k-q8.log 2>&1; row "UD-Q6_K, q8_0/q8_0 cache" $d/b-q6k-q8.log
echo "exit: 0" >> $d/meta.txt
echo KVCTRL-DONE >> $d/results.txt
