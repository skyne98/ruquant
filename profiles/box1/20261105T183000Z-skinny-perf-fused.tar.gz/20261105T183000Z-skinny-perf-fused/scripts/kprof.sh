#!/bin/bash
# kernel-level times of the W4A4 perf cases (test-backend-ops perf), rocprofv3 kernel trace, per build and RQ_SKINNY_SK
export HIP_VISIBLE_DEVICES=1
rm -rf ~/tp/kp; mkdir -p ~/tp/kp
for cfg in ${CFGS:-sk2:0 sk2:1}; do
  b=${cfg%%:*}; sk=${cfg##*:}
  B=$HOME/mx-llama.cpp/build-$b/bin
  LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib RQ_SKINNY_SK=$sk timeout 600 ~/therock-7.12/bin/rocprofv3 --kernel-trace --output-format csv \
    -d ~/tp/kp/$b-$sk -o tr -- $B/test-backend-ops perf -o MUL_MAT -b ROCm0 -p "type_a=w4a4.*n=8" > ~/tp/kp/$b-$sk.log 2>&1
  echo "$b SK=$sk exit $?"
  f=$(find ~/tp/kp/$b-$sk -name "*kernel_trace.csv" | head -1)
  python3 - "$f" <<'PY'
import csv, sys, collections
rows = list(csv.DictReader(open(sys.argv[1])))
agg = collections.defaultdict(list)
for r in rows:
    n = r['Kernel_Name']
    if 'rq_' not in n: continue
    short = n.split('(')[0].replace('void ', '')[:48]
    grid = int(r['Grid_Size_X']) // int(r['Workgroup_Size_X']) * int(r.get('Grid_Size_Y', 1) or 1)
    agg[(short, grid, int(r['Workgroup_Size_X']))].append((int(r['End_Timestamp']) - int(r['Start_Timestamp'])) / 1000)
for k, v in sorted(agg.items()):
    if len(v) < 20: continue
    v = sorted(v)
    print('  %-48s wgs %5d x %4d  n %5d  med %7.2f us' % (k[0], k[1], k[2], len(v), v[len(v) // 2]))
PY
done
