#!/bin/bash
B=$HOME/mx-llama.cpp/build/bin
M=$HOME/models/qwen3.8-27b-ost44-v2-wg64-rb4-gptq.gguf
export LD_LIBRARY_PATH=$B:/opt/rocm/lib HSA_FORCE_FINE_GRAIN_PCIE=1 GGML_CUDA_DISABLE_GRAPHS=1 GGML_META_TOKEN_GRAPH=0
cd ~/tp/sk
HIP_VISIBLE_DEVICES=0,1,2,3 timeout 2400 /opt/rocm/bin/rocprof --timestamp on --basenames on -o ~/tp/sk/t0123.csv \
    $B/llama-bench -m $M -ngl 99 -fa 1 -lm dio -sm tensor -p 8 -n 0 -r 2 > ~/tp/sk/t0123.log 2>&1
echo "exit $? $(wc -l < ~/tp/sk/t0123.csv) rows"
echo PROF4-DONE
