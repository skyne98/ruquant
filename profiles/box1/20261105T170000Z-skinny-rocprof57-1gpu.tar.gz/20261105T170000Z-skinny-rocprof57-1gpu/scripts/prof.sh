#!/bin/bash
B=$HOME/mx-llama.cpp/build/bin
M=$HOME/models/qwen3.8-27b-ost44-v2-wg64-rb4-gptq.gguf
export LD_LIBRARY_PATH=$B:/opt/rocm/lib HSA_FORCE_FINE_GRAIN_PCIE=1 GGML_CUDA_DISABLE_GRAPHS=1 GGML_META_TOKEN_GRAPH=0
rm -rf ~/tp/sk; mkdir -p ~/tp/sk; cd ~/tp/sk
for g in 0 0,1,2,3; do
  sm=; [ $g != 0 ] && sm="-sm tensor"
  n=$(echo $g | tr -d ,)
  HIP_VISIBLE_DEVICES=$g timeout 600 /opt/rocm/bin/rocprof --timestamp on --basenames on -o ~/tp/sk/t$n.csv \
    $B/llama-bench -m $M -ngl 99 -fa 1 -lm dio $sm -p 8 -n 0 -r 5 > ~/tp/sk/t$n.log 2>&1
  echo "g$g exit $? $(wc -l < ~/tp/sk/t$n.csv) rows"
done
head -2 ~/tp/sk/t0.csv
