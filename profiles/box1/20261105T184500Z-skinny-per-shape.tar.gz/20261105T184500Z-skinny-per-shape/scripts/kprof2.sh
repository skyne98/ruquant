#!/bin/bash
# kernel-level time of the skinny kernel per W4A4 shape (test-backend-ops perf, rocprofv3 kernel trace)
export HIP_VISIBLE_DEVICES=1 GGML_CUDA_DISABLE_FUSION=1
rm -rf ~/tp/kp2; mkdir -p ~/tp/kp2
for shape in w4a4:4096:5120 w4a4:8704:5120 w4a4:3584:5120 w4a4h:5120:4352 w4a4h:5120:1536 w4a4:16384:5120 w4a4:34816:5120 w4a4h:5120:17408 w4a4h:5120:6144; do
  IFS=: read t m k <<< "$shape"
  line="$t ${m}x${k}:"
  for cfg in ${CFGS:-sk2:0 sk2:1}; do
    b=${cfg%%:*}; sk=${cfg##*:}
    B=$HOME/mx-llama.cpp/build-$b/bin
    d=~/tp/kp2/$b-$sk-$m-$k
    LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib RQ_SKINNY_SK=$sk timeout 300 ~/therock-7.12/bin/rocprofv3 --kernel-trace --output-format csv \
      -d $d -o tr -- $B/test-backend-ops perf -o MUL_MAT -b ROCm0 -p "type_a=$t,type_b=f32,m=$m,n=8,k=$k," > $d.log 2>&1
    f=$(find $d -name "*kernel_trace.csv" | head -1)
    r=$(python3 - "$f" <<'PY'
import csv, sys, collections
rows = list(csv.DictReader(open(sys.argv[1])))
v = collections.defaultdict(list)
for r in rows:
    n = r['Kernel_Name']
    if 'rq_skinny' not in n: continue
    g = int(r['Grid_Size_X']) // int(r['Workgroup_Size_X']) * int(r.get('Grid_Size_Y', 1) or 1)
    v[g].append((int(r['End_Timestamp']) - int(r['Start_Timestamp'])) / 1000)
g, x = max(v.items(), key=lambda kv: len(kv[1]))
x.sort()
print('%d wgs %.2f us' % (g, x[len(x) // 2]))
PY
)
    line="$line  $b/SK$sk $r;"
  done
  echo "$line"
done
