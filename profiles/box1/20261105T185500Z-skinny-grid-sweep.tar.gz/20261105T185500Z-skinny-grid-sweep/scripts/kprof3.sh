#!/bin/bash
export HIP_VISIBLE_DEVICES=1 GGML_CUDA_DISABLE_FUSION=1
B=$HOME/mx-llama.cpp/build-sk2/bin
run() { # label, env..., shape: t m k
  local lab=$1; shift; local t=$1 m=$2 k=$3; shift 3
  local d=~/tp/kp3/$lab-$m-$k; rm -rf $d
  env "$@" LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib timeout 300 ~/therock-7.12/bin/rocprofv3 --kernel-trace --output-format csv \
      -d $d -o tr -- $B/test-backend-ops perf -o MUL_MAT -b ROCm0 -p "type_a=$t,type_b=f32,m=$m,n=8,k=$k," > $d.log 2>&1
  python3 - "$(find $d -name '*kernel_trace.csv' | head -1)" "$lab" <<'PY'
import csv, sys, collections
v = collections.defaultdict(list)
for r in csv.DictReader(open(sys.argv[1])):
    if 'rq_skinny' not in r['Kernel_Name']: continue
    g = int(r['Grid_Size_X']) // int(r['Workgroup_Size_X']) * int(r['Grid_Size_Y'])
    v[g].append((int(r['End_Timestamp']) - int(r['Start_Timestamp'])) / 1000)
g, x = max(v.items(), key=lambda kv: len(kv[1])); x.sort()
print('    %-16s %4d wgs %7.2f us' % (sys.argv[2], g, x[len(x) // 2]))
PY
}
mkdir -p ~/tp/kp3
echo "w4a4h 5120x6144 (40 tiles, 96 groups)"
for g in 1 2 3; do run "SK0-G$g" w4a4h 5120 6144 RQ_SKINNY_SK=0 RQ_SKINNY_G=$g; done
for sl in 40 80 120; do run "SK1-slots$sl" w4a4h 5120 6144 RQ_SKINNY_SK=1 RQ_SKINNY_SK_SLOTS=$sl; done
echo "w4a4 4096x5120 (32 tiles, 80 groups)"
for g in 1 2 4; do run "SK0-G$g" w4a4 4096 5120 RQ_SKINNY_SK=0 RQ_SKINNY_G=$g; done
for sl in 32 64 120; do run "SK1-slots$sl" w4a4 4096 5120 RQ_SKINNY_SK=1 RQ_SKINNY_SK_SLOTS=$sl; done
