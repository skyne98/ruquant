#!/bin/bash
export HIP_VISIBLE_DEVICES=1 GGML_CUDA_DISABLE_FUSION=1
B=$HOME/mx-llama.cpp/build-sk2/bin
d=~/tp/pmc/test; rm -rf $d; mkdir -p $d
LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib timeout 300 ~/therock-7.12/bin/rocprofv3 --pmc TCC_EA_RDREQ TCC_EA_RDREQ_32B \
  --kernel-include-regex rq_skinny --output-format csv -d $d -o tr -- $B/test-backend-ops perf -o MUL_MAT -b ROCm0 \
  -p "type_a=w4a4,type_b=f32,m=4096,n=8,k=5120," > $d.log 2>&1
echo exit $?; tail -3 $d.log; find $d -name "*.csv" | head; f=$(find $d -name "*counter_collection.csv" | head -1); head -3 "$f"; wc -l "$f"
