#!/bin/bash
# rocprofv3 counters of the skinny kernel per shape (single launches), median over dispatches
export HIP_VISIBLE_DEVICES=1 GGML_CUDA_DISABLE_FUSION=1
B=$HOME/mx-llama.cpp/build-sk2/bin
CGROUPS=("FETCH_SIZE GRBM_GUI_ACTIVE" "MemUnitBusy MemUnitStalled" "TA_BUSY_avr TA_BUSY_max" "VALUBusy SALUBusy" "SQ_INSTS_VALU SQ_INSTS_VMEM_RD SQ_INSTS_SMEM SQ_INSTS_SALU SQ_WAVES" "L2CacheHit GPUBusy")
for cfg in "def w4a4 4096 5120 RQ_SKINNY_SK=0" "def w4a4 8704 5120 RQ_SKINNY_SK=0" "def w4a4 34816 5120 RQ_SKINNY_SK=0" "def w4a4h 5120 6144 RQ_SKINNY_SK=0" \
           "sk100 w4a4h 5120 6144 RQ_SKINNY_SK=1 RQ_SKINNY_SK_SLOTS=100" "sk120 w4a4h 5120 6144 RQ_SKINNY_SK=1 RQ_SKINNY_SK_SLOTS=120"; do
  set -- $cfg; lab=$1 t=$2 m=$3 k=$4; shift 4
  out="$lab $t ${m}x${k}:"
  gi=0
  for g in "${CGROUPS[@]}"; do
    d=~/tp/pmc/$lab-$m-$k-$gi; rm -rf $d
    env "$@" LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib timeout 300 ~/therock-7.12/bin/rocprofv3 --pmc $g --kernel-include-regex rq_skinny \
      --output-format csv -d $d -o tr -- $B/test-backend-ops perf -o MUL_MAT -b ROCm0 -p "type_a=$t,type_b=f32,m=$m,n=8,k=$k," > $d.log 2>&1
    out="$out $(python3 - $(find $d -name '*counter_collection.csv' | head -1) <<'PY'
import csv, sys, collections
v = collections.defaultdict(lambda: collections.defaultdict(list))
grid = collections.Counter()
for r in csv.DictReader(open(sys.argv[1])):
    grid[r['Grid_Size']] += 1
    v[r['Grid_Size']][r['Counter_Name']].append(float(r['Counter_Value']))
g = grid.most_common(1)[0][0]
print(' '.join('%s=%.4g' % (k, sorted(x)[len(x) // 2]) for k, x in v[g].items()) + ' [wgs %d]' % (int(g) // 512))
PY
)"
    gi=$((gi + 1))
  done
  echo "$out"
done
