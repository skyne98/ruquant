#!/bin/bash
# plausibility of the inferred gfx906 counters on the 64-workgroup launch (512 waves, 30.6 us = ~52.8k cycles at 1725 MHz)
export HIP_VISIBLE_DEVICES=1 GGML_CUDA_DISABLE_FUSION=1 ROCPROFILER_METRICS_PATH=$HOME/tp/rpdefs
B=$HOME/mx-llama.cpp/build-sk2/bin
for g in "RQ_SQ_WAVE_CYCLES RQ_SQ_WAIT_ANY RQ_SQ_WAIT_INST_ANY GRBM_GUI_ACTIVE" "RQ_LEVEL_WAVES_ACC RQ_SQ_BUSY_CYCLES SQ_WAVES GRBM_GUI_ACTIVE" \
         "RQ_LEVEL_VMEM_ACC SQ_INSTS_VMEM_RD SQ_INSTS_VMEM_WR" "RQ_LEVEL_SMEM_ACC SQ_INSTS_SMEM" "RQ_SQ_ACTIVE_INST_VMEM RQ_SQ_ACTIVE_INST_SCA SQ_ACTIVE_INST_VALU" \
         "RQ_TCC_EA_RDREQ_LEVEL TCC_EA_RDREQ_sum RQ_TCC_TAG_STALL RQ_TCC_BUSY"; do
  d=~/tp/pmc/rq5; rm -rf $d
  LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib timeout 300 ~/therock-7.12/bin/rocprofv3 --pmc $g --kernel-include-regex rq_skinny \
    --output-format csv -d $d -o tr -- $B/test-backend-ops perf -o MUL_MAT -b ROCm0 -p "type_a=w4a4,type_b=f32,m=4096,n=8,k=5120," > $d.log 2>&1
  grep -E "Unable|rror" $d.log | head -2
  python3 - $(find $d -name '*counter_collection.csv' | head -1) <<'PY'
import csv, sys, collections
v = collections.defaultdict(list)
for r in csv.DictReader(open(sys.argv[1])):
    if r['Grid_Size'] == '32768': v[r['Counter_Name']].append(float(r['Counter_Value']))
print('  ' + '  '.join('%s=%.4g' % (k, sorted(x)[len(x) // 2]) for k, x in v.items()))
PY
done
