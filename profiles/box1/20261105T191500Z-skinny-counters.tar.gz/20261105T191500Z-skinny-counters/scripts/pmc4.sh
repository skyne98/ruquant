#!/bin/bash
export HIP_VISIBLE_DEVICES=1 GGML_CUDA_DISABLE_FUSION=1
B=$HOME/mx-llama.cpp/build-sk2/bin
for mp in $HOME/tp/rpdefs $HOME/tp/rpdefs/counter_defs.yaml; do
  d=~/tp/pmc/rqtest; rm -rf $d
  ROCPROFILER_METRICS_PATH=$mp LD_LIBRARY_PATH=$B:$HOME/therock-7.12/lib timeout 300 ~/therock-7.12/bin/rocprofv3 --pmc RQ_SQ_WAVE_CYCLES RQ_SQ_WAIT_ANY \
    --kernel-include-regex rq_skinny --output-format csv -d $d -o tr -- $B/test-backend-ops perf -o MUL_MAT -b ROCm0 \
    -p "type_a=w4a4,type_b=f32,m=4096,n=8,k=5120," > $d.log 2>&1
  echo "$mp: exit $?"; grep -iE "error|not found|invalid|RQ_" $d.log | head -5
  f=$(find $d -name "*counter_collection.csv" | head -1); [ -n "$f" ] && sed -n 2,3p $f | cut -d, -f16-17
done
